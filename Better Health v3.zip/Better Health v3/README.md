# Better Health Website

A modern and elegant website for Better Health, featuring a responsive design and appointment booking functionality.

## Pages

- **Home**: Main landing page with hero section and appointment booking
- **About Us**: Information about Better Health (coming soon)
- **Services**: List of services offered (coming soon)
- **Privacy Policy**: Privacy policy details (coming soon)
- **Terms & Conditions**: Terms and conditions details (coming soon)

## Features

- Responsive design that works on mobile, tablet, and desktop
- Google Calendar integration for appointment scheduling
- Clean and modern user interface
- Easy navigation with a mobile-friendly hamburger menu

## Technology Stack

- HTML5
- CSS3
- JavaScript (vanilla)
- Google Calendar API for appointment scheduling

## How to Use

1. Clone the repository
2. Open `index.html` in your web browser
3. Navigate through the website using the navigation menu
4. Book an appointment using the Google Calendar integration

## Color Scheme

- Background Color: #fffae3
- Button Background Color: #ec5228
- Heading Color: #000080
- Text Color: Black

## License

This project is licensed under the MIT License.

# Better Health Career Application Form Handler

This repository contains the code for the Better Health careers website, including job application form handling with Google Sheets integration.

## Setup Instructions for Google Apps Script

To set up the form submission handler:

1. **Create a Google Sheet**:
   - The sheet is already set up with ID: `1Zr-sZbAJICSwzRzkpDIRmMjARNhP_kdvI_vBFFr9ldw`
   - Make sure you have edit access to this sheet

2. **Set Up Google Apps Script**:
   - Go to [Google Apps Script](https://script.google.com/home)
   - Click "New Project"
   - Delete any code in the editor and replace it with the contents of `apps_script.js` from this repository
   - Save the project (File > Save) and give it a name (e.g., "Better Health Form Handler")

3. **Deploy as Web App**:
   - Click "Deploy" > "New deployment"
   - Select type: "Web app"
   - Configure the following settings:
     - Description: "Better Health Form Handler"
     - Execute as: "Me" (your Google account)
     - Who has access: "Anyone, even anonymous"
   - Click "Deploy"
   - Copy the generated Web App URL - this is your script URL for the form

4. **Update HTML File**:
   - In the `apply.html` file, locate the line with `const scriptURL = '...'`
   - Replace the URL with your newly generated Web App URL
   - This step is already done if you're using the provided script URL

5. **Test the Integration**:
   - Open the Apps Script editor
   - Run the `testSpreadsheetAccess()` function to verify sheet access
   - Fill out the application form on your website and submit
   - Check the Google Sheet to confirm data is being recorded

## Troubleshooting

If form submissions aren't working:

1. Check browser console for errors
2. Verify the script URL is correct
3. Make sure the spreadsheet ID in the Apps Script matches the actual spreadsheet
4. Check Apps Script execution logs for errors:
   - In the Apps Script editor, go to "Executions" in the left sidebar
   - Review any error messages

## Form Fields Mapping

The form collects the following data and maps it to the Google Sheet columns:

- Timestamp (automatic)
- Job Role
- Name
- Email
- LinkedIn URL
- Resume URL
- Country Code
- Phone Number
- City
- State
- Country

Each submission creates a new row in the "Applications" sheet. 