/**
 * Better Health - Job Application Form Handler
 * 
 * This script processes job applications submitted from the Better Health careers page
 * and records them in a Google Sheet.
 */

// Replace with your actual spreadsheet ID
const SPREADSHEET_ID = '1Zr-sZbAJICSwzRzkpDIRmMjARNhP_kdvI_vBFFr9ldw';

/**
 * Process form data from web app
 */
function doPost(e) {
  try {
    // Log the entire event for debugging
    Logger.log('Received form submission: ' + JSON.stringify(e));
    
    // Handle different ways form data might be received
    let formData;
    
    if (e && e.parameter) {
      // Standard form submission with URL parameters
      formData = e.parameter;
      Logger.log('Using e.parameter for form data');
    } else if (e && e.postData && e.postData.contents) {
      // JSON or other content type in request body
      try {
        formData = JSON.parse(e.postData.contents);
        Logger.log('Parsed JSON from request body');
      } catch (parseError) {
        // If JSON parsing fails, try to handle form-urlencoded content
        try {
          const rawContent = e.postData.contents;
          formData = {};
          rawContent.split('&').forEach(item => {
            const parts = item.split('=');
            if (parts.length === 2) {
              formData[decodeURIComponent(parts[0])] = decodeURIComponent(parts[1]);
            }
          });
          Logger.log('Parsed form-urlencoded from request body');
        } catch (formError) {
          Logger.log('Error parsing form data: ' + formError);
          formData = {};
        }
      }
    } else if (e && typeof e === 'object') {
      // If e is the data itself (unusual but possible)
      formData = e;
      Logger.log('Using event object directly as form data');
    } else {
      // Fallback - create empty object
      formData = {};
      Logger.log('No valid form data found, using empty object');
    }
    
    // Validate if we have any data to work with
    if (!formData || Object.keys(formData).length === 0) {
      Logger.log('No usable form data received');
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'No usable form data received'
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Log the extracted form data
    Logger.log('Extracted form data: ' + JSON.stringify(formData));
    
    // Log each field individually for debugging
    Logger.log('timestamp: ' + formData.timestamp);
    Logger.log('jobRole: ' + formData.jobRole);
    Logger.log('name: ' + formData.name);
    Logger.log('email: ' + formData.email);
    Logger.log('countryCode: ' + formData.countryCode);
    Logger.log('phone: ' + formData.phone);
    Logger.log('city: ' + formData.city);
    Logger.log('state: ' + formData.state);
    Logger.log('country: ' + formData.country);
    Logger.log('linkedin: ' + formData.linkedin);
    Logger.log('resumeLink: ' + formData.resumeLink);
    
    // Format timestamp
    let timestamp;
    try {
      timestamp = formData.timestamp ? new Date(formData.timestamp) : new Date();
      // If timestamp is invalid, use current date
      if (isNaN(timestamp.getTime())) {
        timestamp = new Date();
      }
    } catch (err) {
      timestamp = new Date();
      Logger.log('Error parsing timestamp, using current date: ' + err);
    }
    
    // Access spreadsheet
    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    if (!spreadsheet) {
      throw new Error('Could not open spreadsheet with ID: ' + SPREADSHEET_ID);
    }
    
    // Get or create the Applications sheet
    let sheet = spreadsheet.getSheetByName('Applications');
    if (!sheet) {
      sheet = spreadsheet.insertSheet('Applications');
      
      // Add headers
      sheet.appendRow([
        'Timestamp', 
        'Job Role', 
        'Name', 
        'Email', 
        'Country Code', 
        'Phone', 
        'City', 
        'State', 
        'Country', 
        'LinkedIn Profile', 
        'Resume Link'
      ]);
      
      // Format header row
      sheet.getRange(1, 1, 1, 11).setFontWeight('bold').setBackground('#f3f3f3');
    }
    
    // Prepare data for row insertion, ensuring each field is properly handled
    const rowData = [
      Utilities.formatDate(timestamp, Session.getScriptTimeZone(), 'MM/dd/yyyy HH:mm:ss'),
      formData.jobRole || '',
      formData.name || '',
      formData.email || '',
      formData.countryCode || '',  // Already has + removed in frontend
      formData.phone || '',
      formData.city || '',
      formData.state || '',
      formData.country || '',
      formData.linkedin || '',  // Make sure field name matches frontend
      formData.resumeLink || '' // Make sure field name matches frontend
    ];
    
    // Log what we're about to save
    Logger.log('Adding row with data: ' + JSON.stringify(rowData));
    
    // Append the data
    sheet.appendRow(rowData);
    
    // Log success
    Logger.log('Successfully added application for: ' + formData.name);
    
    // Create the response content
    const responseContent = JSON.stringify({
      success: true,
      message: 'Application submitted successfully',
      received: formData // Include received data for debugging
    });
    
    // Create response with CORS headers
    return ContentService.createTextOutput(responseContent)
      .setMimeType(ContentService.MimeType.JSON)
      .setHeader('Access-Control-Allow-Origin', '*')
      .setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
      .setHeader('Access-Control-Allow-Headers', 'Content-Type');
  } catch (error) {
    // Log the error
    Logger.log('Error in doPost: ' + error.toString());
    Logger.log('Stack trace: ' + error.stack);
    
    // Create error response with CORS headers
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: 'Error: ' + error.message
    }))
    .setMimeType(ContentService.MimeType.JSON)
    .setHeader('Access-Control-Allow-Origin', '*')
    .setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    .setHeader('Access-Control-Allow-Headers', 'Content-Type');
  }
}

/**
 * Test function to verify spreadsheet access
 */
function testSpreadsheetAccess() {
  try {
    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheets = spreadsheet.getSheets();
    const sheetNames = sheets.map(s => s.getName()).join(', ');
    
    Logger.log('Successfully accessed spreadsheet. Sheets: ' + sheetNames);
    return 'Success! Spreadsheet accessible. Sheets: ' + sheetNames;
  } catch (error) {
    Logger.log('Error accessing spreadsheet: ' + error.message);
    return 'Error: ' + error.message;
  }
}

/**
 * Test function to add sample data
 */
function testAddRow() {
  try {
    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = spreadsheet.getSheetByName('Applications') || spreadsheet.insertSheet('Applications');
    
    // Add a test row
    sheet.appendRow([
      new Date().toLocaleString(),
      'Test Job',
      'Test Name',
      'test@example.com',
      '91', // No + sign as we're removing it in frontend
      '9876543210',
      'Test City',
      'Test State',
      'Test Country',
      'https://linkedin.com/in/test',
      'https://example.com/resume.pdf'
    ]);
    
    Logger.log('Successfully added test data');
    return 'Test data added successfully';
  } catch (error) {
    Logger.log('Error in testAddRow: ' + error.message);
    return 'Error: ' + error.message;
  }
}

/**
 * Handle OPTIONS requests for CORS preflight
 */
function doOptions(e) {
  return ContentService.createTextOutput('')
    .setMimeType(ContentService.MimeType.TEXT)
    .setHeader('Access-Control-Allow-Origin', '*')
    .setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    .setHeader('Access-Control-Allow-Headers', 'Content-Type')
    .setHeader('Access-Control-Max-Age', '3600');
}

/**
 * Simple GET handler for testing the deployment
 */
function doGet() {
  return HtmlService.createHtmlOutput(`
    <h1>Better Health Job Application Form Handler</h1>
    <p>This web app processes job applications and adds them to a Google Sheet.</p>
    <p>Status: <span style="color: green; font-weight: bold;">Active</span></p>
    <p>Last updated: ${new Date().toLocaleString()}</p>
  `);
} 