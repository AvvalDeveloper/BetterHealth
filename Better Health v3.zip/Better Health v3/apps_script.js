/**
 * Google Apps Script code for handling form submissions from Better Health job application form
 * This script processes form data sent from apply.html and adds it to a Google Sheet
 */

function doPost(e) {
  try {
    // Ensure we have an event object and parameters
    if (!e || !e.parameter) {
      throw new Error('No event object or parameters found in request.');
    }

    Logger.log('📥 RECEIVED EVENT: ' + JSON.stringify(e));
    
    // Always use e.parameter to safely get form data
    // This is pre-parsed by Google and handles URL encoding properly
    const formData = e.parameter;
    Logger.log('📋 FORM DATA OVERVIEW: ' + JSON.stringify(formData));
    
    // Detailed field logging
    Logger.log('---- INDIVIDUAL FIELD CHECK ----');
    Logger.log('✔ timestamp: ' + formData.timestamp);
    Logger.log('✔ jobRole: ' + formData.jobRole);
    Logger.log('✔ name: ' + formData.name);
    Logger.log('✔ email: ' + formData.email);
    Logger.log('✔ linkedin: ' + formData.linkedin);
    Logger.log('✔ resumeLink: ' + formData.resumeLink);
    Logger.log('✔ countryCode: ' + formData.countryCode);
    Logger.log('✔ phone: ' + formData.phone);
    Logger.log('✔ city: ' + formData.city);
    Logger.log('✔ state: ' + formData.state);
    Logger.log('✔ country: ' + formData.country);
    Logger.log('✔ submission_method: ' + formData.submission_method);
    
    // Basic validation - make sure we have data
    if (Object.keys(formData).length === 0) {
      throw new Error('Empty form data received');
    }
    
    // Access the spreadsheet using openById instead of getActiveSpreadsheet
    // This ensures the script works when deployed as a Web App
    const spreadsheetId = '1Zr-sZbAJICSwzRzkpDIRmMjARNhP_kdvI_vBFFr9ldw'; // Replace with your actual spreadsheet ID
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    
    if (!spreadsheet) {
      throw new Error('Could not access spreadsheet');
    }
    
    // Get or create the "Job Applications" sheet
    let sheet = spreadsheet.getSheetByName('Job Applications');
    if (!sheet) {
      Logger.log('Sheet "Job Applications" not found. Creating it...');
      sheet = spreadsheet.insertSheet('Job Applications');
      
      // Add headers - IMPORTANT: Match the exact order of your spreadsheet columns
      sheet.appendRow([
        'Timestamp',        // A
        'Job Role',         // B
        'Name',             // C
        'Email',            // D
        'Country Code',     // E
        'Phone',            // F
        'City',             // G
        'State',            // H
        'Country',          // I
        'LinkedIn Profile',  // J
        'Resume Link'       // K
      ]);
      
      // Format header row
      sheet.getRange(1, 1, 1, 11).setFontWeight('bold');
    }
    
    // Check existing sheet structure
    const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    Logger.log('📊 SHEET HEADERS: ' + JSON.stringify(headers));
    Logger.log('🔢 Number of columns in sheet: ' + sheet.getLastColumn());
    
    // Process and clean field values
    const cleanedData = {
      timestamp: formData.timestamp || new Date().toISOString(),
      jobRole: formData.jobRole || '',
      name: formData.name || '',
      email: formData.email || '',
      // Ensure countryCode always has a value, even if the + was removed
      countryCode: (formData.countryCode && formData.countryCode.trim()) || '0',
      phone: formData.phone || '',
      city: formData.city || '',
      state: formData.state || '',
      country: formData.country || '',
      linkedin: formData.linkedin || '',
      resumeLink: formData.resumeLink || ''
      // Removed submissionMethod from here as we'll check if it's needed
    };
    
    // Prepare row data array - this will be used with appendRow
    const rowData = [
      cleanedData.timestamp,       // A
      cleanedData.jobRole,         // B
      cleanedData.name,            // C
      cleanedData.email,           // D
      cleanedData.countryCode,     // E
      cleanedData.phone,           // F
      cleanedData.city,            // G
      cleanedData.state,           // H
      cleanedData.country,         // I
      cleanedData.linkedin,        // J
      cleanedData.resumeLink       // K
    ];
    
    // Log row data for debugging
    Logger.log('📝 READY TO INSERT DATA:');
    Logger.log('🔢 Number of fields to insert: ' + rowData.length);
    for (let i = 0; i < rowData.length; i++) {
      Logger.log(`Field ${i} (${headers[i] || 'UNKNOWN'}): ${rowData[i]}`);
    }
    
    // Check if any critical fields are empty
    if (!cleanedData.linkedin) {
      Logger.log('⚠️ WARNING: LinkedIn field is empty!');
    }
    if (!cleanedData.resumeLink) {
      Logger.log('⚠️ WARNING: Resume Link field is empty!');
    }
    
    // Append data to sheet
    sheet.appendRow(rowData);
    Logger.log('✅ Data successfully inserted into sheet');
    
    // Return a success response
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'Application submitted successfully',
      timestamp: new Date().toISOString(),
      insertedData: cleanedData // Return what was inserted for verification
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    // Log the full error
    Logger.log('❌ ERROR in doPost: ' + error.toString());
    Logger.log('Error stack: ' + (error.stack || 'No stack trace available'));
    
    // Return a structured error response
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: 'Error processing application: ' + error.message,
      timestamp: new Date().toISOString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Simple test form for isolating submission issues
 */
function doGet() {
  return HtmlService.createHtmlOutput(`
    <h2>Test Form for Job Application</h2>
    <form id="miniForm">
      <div>
        <label for="name">Name:</label>
        <input name="name" id="name" value="Test User" />
      </div>
      <div>
        <label for="linkedin">LinkedIn:</label>
        <input name="linkedin" id="linkedin" value="https://linkedin.com/in/test" />
      </div>
      <div>
        <label for="resumeLink">Resume Link:</label>
        <input name="resumeLink" id="resumeLink" value="https://drive.google.com/test" />
      </div>
      <button type="submit">Test Submit</button>
    </form>
    
    <script>
      document.getElementById('miniForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const params = new URLSearchParams();
        
        for (const [key, value] of formData.entries()) {
          params.append(key, value);
          console.log(key + ' = ' + value);
        }
        
        fetch('', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString()
        })
        .then(response => response.json())
        .then(data => {
          alert('Response: ' + JSON.stringify(data));
        })
        .catch(error => {
          alert('Error: ' + error.message);
        });
      });
    </script>
  `);
}

/**
 * Optional method for testing the script directly from the Apps Script editor
 */
function testDoPost() {
  // Simulate form data for testing
  const e = {
    parameter: {
      timestamp: new Date().toISOString(),
      jobRole: 'Social Media Content Creator Intern',
      name: 'Test User',
      email: 'test@example.com',
      countryCode: '91',  // Test both with and without the + symbol
      phone: '9876543210',
      city: 'Test City',
      state: 'Test State',
      country: 'India',
      linkedin: 'https://linkedin.com/in/testuser',
      resumeLink: 'https://drive.google.com/file/d/12345'
    }
  };
  
  // Call doPost with test data
  const result = doPost(e);
  Logger.log('Test result: ' + result.getContent());
  
  // Test with empty country code
  e.parameter.countryCode = '';
  const result2 = doPost(e);
  Logger.log('Test result with empty country code: ' + result2.getContent());
} 