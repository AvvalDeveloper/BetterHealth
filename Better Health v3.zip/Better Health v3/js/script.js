// Mobile Menu Toggle
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navLinks.classList.toggle('active');
    });
}

// Appointment Popup Functionality
const appointmentPopup = document.getElementById('appointmentPopup');
const openAppointmentBtns = document.querySelectorAll('.open-appointment');
const closePopupBtn = document.getElementById('closePopup');

if (appointmentPopup && closePopupBtn) {
    // Open popup
    openAppointmentBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            appointmentPopup.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    // Close popup
    closePopupBtn.addEventListener('click', () => {
        appointmentPopup.classList.remove('active');
        document.body.style.overflow = '';
    });

    // Close popup when clicking outside
    appointmentPopup.addEventListener('click', (e) => {
        if (e.target === appointmentPopup) {
            appointmentPopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Close popup on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && appointmentPopup.classList.contains('active')) {
            appointmentPopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add shadow to navbar on scroll
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('nav');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
});

// Animation for elements when they come into view
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.animate-on-scroll').forEach(element => {
    observer.observe(element);
});

// NOTE: Form submission is handled directly in apply.html 