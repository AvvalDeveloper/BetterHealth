# Deployment Guide for Better Health Website

This guide provides instructions for deploying the Better Health website with the Google Apps Script integration for form handling.

## Hosting the Website

### Option 1: GitHub Pages (Free)
1. Push your code to a GitHub repository
2. Go to repository Settings > Pages
3. Set source to your main branch
4. Your site will be available at `https://[username].github.io/[repository-name]`

### Option 2: Netlify (Free tier available)
1. Create an account at [Netlify](https://www.netlify.com/)
2. Connect your GitHub repository
3. Set build settings if needed (typically not required for this static site)
4. Deploy the site

### Option 3: Vercel (Free tier available)
1. Create an account at [Vercel](https://vercel.com/)
2. Import your GitHub repository
3. Configure project settings (typically automatic for static sites)
4. Deploy the site

## Google Apps Script Deployment Steps

1. **Create and prepare Google Sheet**:
   ```
   Sheet Name: Better Health Job Applications
   First tab name: Applications
   Header row: Timestamp, Job Role, Name, Email, LinkedIn URL, Resume URL, Country Code, Phone Number, City, State, Country
   ```

2. **Copy Spreadsheet ID**:
   - From the spreadsheet URL: `https://docs.google.com/spreadsheets/d/[THIS_IS_YOUR_SPREADSHEET_ID]/edit`
   - Example ID: `1Zr-sZbAJICSwzRzkpDIRmMjARNhP_kdvI_vBFFr9ldw`

3. **Create Apps Script Project**:
   - Go to [Google Apps Script](https://script.google.com/home)
   - Click "New Project"
   - Paste the code from `apps_script.js` into the editor
   - Update the `SPREADSHEET_ID` constant with your sheet's ID
   - Save the project with a meaningful name

4. **Configure Deployment**:
   - Click "Deploy" > "New deployment"
   - Choose "Web app" as type
   - Set description: "Better Health Form Handler"
   - Execute as: "Me" (your account)
   - Who has access: "Anyone, even anonymous"
   - Click "Deploy"
   - Copy the web app URL

5. **Update Website Code**:
   - Edit `apply.html` to update the script URL:
   ```javascript
   const scriptURL = 'YOUR_SCRIPT_URL_HERE';
   ```

6. **Test the Integration**:
   - Fill out and submit the form on your website
   - Check the Google Sheet for the submitted data
   - Review any error messages in the browser console

## Security Considerations

1. The Google Apps Script runs with your account permissions
2. Form data is stored in your Google Sheet
3. Anyone can submit to your form if they have the URL
4. Consider adding reCAPTCHA if spam becomes an issue

## Maintenance

- Periodically check the Google Sheet for data integrity
- If the form stops working, you may need to redeploy the Apps Script (deployments expire after some time)
- Keep backup copies of the spreadsheet data regularly 